<?php
$servnam='localhost';
$usnam='Markiewicz';
$password='1234';
$db='Markiewicz';

$conn = new mysqli($servnam, $usnam, $password, $db );
?>